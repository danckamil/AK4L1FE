# Yet Another Bombuj Plugin

![Yet Another Bombuj Plugin](plugin.video.yabop/icon.png)

## Kodi Video Plugin / YABoP

Plugin prehrá obsah z Bombuj.si.

Používa na to android api, ktoré používa aj oficiálna [android aplikácia](https://play.google.com/store/apps/details?id=com.tosi.bombujmanual).  

Plugin neposkytuje žiaden obsah, je to len simulácia prehliadača verejne dostupnej web stránky resp. android aplikácie. Nie som zodpovedný za obsah, ktorý táto stránka poskytuje.

## Závislosti
Plugin vyžaduje [script.module.resolveurl](https://github.com/jsergio123/script.module.resolveurl).

## Diskusia
[https://www.xbmc-kodi.cz/prispevek-yet-another-bombuj-plugin](https://www.xbmc-kodi.cz/prispevek-yet-another-bombuj-plugin)

## Epilóg
Plugin vznikol ako moje programátorské cvičenie, demonštrácia "dá sa to". Z toho dôvodu nedokážem zaručiť, že bude fungovať navždy.
